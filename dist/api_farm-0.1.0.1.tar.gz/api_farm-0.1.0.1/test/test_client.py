from api_farm.client_sdk import APIPoolClient
import asyncio

def test():
    # Initialize client
    client = APIPoolClient(server_url="http://localhost:8081")

    # 1. Register
    print("Registering...")
    try:
        resp = client.register("sdk_user", "sdk_pass")
        print(f"Register Response 1: {resp['message']}, User ID: {resp['user_id']}")
        
        # Register again (should not fail)
        resp = client.register("sdk_user", "sdk_pass")
        print(f"Register Response 2: {resp['message']}, User ID: {resp['user_id']}")
        assert resp['message'] == "User already exists"
    except Exception as e:
        print(f"Registration failed: {e}")

    # 2. Login
    print("Logging in...")
    token = client.login("sdk_user", "sdk_pass")
    print(f"Token: {token}")

    # 3. Add Key
    print("Adding Key...")
    client.add_key(None)

    # 4. Call LLM Generation (Inference)
    # This uses the shared pool of keys.
    print("Calling LLM...")
    try:
        response = asyncio.run(client.chat_completions(
            model="qwen/qwen2.5-coder-7b-instruct",
            messages=[{"role": "user", "content": "Hello!"}]
        ))
        print("Response:", response)
    except Exception as e:
        print(f"Inference failed (expected if key is dummy): {e}")

    try: 
        responses = asyncio.run(client.batch_chat_completions(
            model="qwen/qwen2.5-coder-7b-instruct",
            messages=[
                [{"role": "user", "content": "Hello!"}]
            ]
        ))
        print("Responses:", responses)
    except Exception as e:
        print(f"Batch inference failed (expected if key is dummy): {e}")


    # 4. Remove Key
    print("Removing Key...")
    print(client.remove_key(None))

    # 5. Logout
    print("Logging out...")
    client.logout()

    # Verify Logout
    try:
        client.list_keys()
    except RuntimeError as e:
        print(f"Caught expected error after logout: {e}")

if __name__ == "__main__":
    test()