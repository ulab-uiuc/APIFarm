"""
Allow running the CLI via: python -m api_farm
"""
from api_farm.cli import main

if __name__ == "__main__":
    main()
